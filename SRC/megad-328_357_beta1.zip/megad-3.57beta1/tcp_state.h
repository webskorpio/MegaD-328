#define IO_SIZE 16
extern uint8_t tcp_client_state;
extern uint8_t cur_input;
